const authJwt = require("./authJwt");
const verifySignUp = require("./verfySignUp");

module.exports = {
  authJwt,
  verifySignUp
};