module.exports = {
    HOST: "localhost",
    PORT: 27017,
    DB: "ahinternationals_db"
  };