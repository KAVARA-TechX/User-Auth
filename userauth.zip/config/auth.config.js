module.exports = {
    secret: "ah-waalo-ki-secret-key"
  };